#!/usr/bin/env bash
# NERCEL v7.0 — lanceur. Démarre l'orchestrateur et l'edge, sans ouvrir
# de navigateur sauf option --open explicite.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
DATA_DIR="${NERCEL_DATA:-$HOME/.nercel}"
export NERCEL_DATA="$DATA_DIR"
LOG_DIR="$DATA_DIR/logs"
mkdir -p "$LOG_DIR" "$DATA_DIR" "$DATA_DIR/ai" "$DATA_DIR/apps" "$DATA_DIR/uploads"

G=$'\033[0;32m'; R=$'\033[0;31m'; C=$'\033[0;36m'; B=$'\033[1m'; N=$'\033[0m'
ok(){  printf "${G}✓${N} %s\n" "$*"; }
err(){ printf "${R}✗ %s${N}\n" "$*" >&2; }
info(){ printf "${C}▸${N} %s\n" "$*"; }

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys;sys.exit(0 if sys.version_info>=(3,8) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done

port_up(){ "$PY" -c "import socket,sys;s=socket.socket();s.settimeout(0.5);sys.exit(0 if s.connect_ex(('127.0.0.1', $1))==0 else 1)" 2>/dev/null; }

stop_all(){
  for f in "$DATA_DIR/nercel.pid" "$DATA_DIR/nexusd.pid"; do
    [ -f "$f" ] && kill "$(cat "$f" 2>/dev/null)" 2>/dev/null && rm -f "$f"
  done
  pkill -f "$HERE/server.py" 2>/dev/null
  pkill -f "$HERE/nexusd.py" 2>/dev/null
}

PORT="$("$PY" -c 'import json,os
try: print(int(json.load(open(os.environ["NERCEL_DATA"]+"/config.json")).get("serveur.port",3923)))
except Exception: print(3923)' 2>/dev/null || echo 3923)"
EDGE_PORT="$("$PY" -c 'import json,os
try: print(int(json.load(open(os.environ["NERCEL_DATA"]+"/config.json")).get("serveur.edge_port",8765)))
except Exception: print(8765)' 2>/dev/null || echo 8765)"

OPEN_BROWSER="0"
case "${1:-}" in
  --stop)    stop_all; ok "NERCEL arrêté"; exit 0 ;;
  --status)  [ -z "$PY" ] && { err "Python 3.8+ requis"; exit 1; }; exec "$PY" "$HERE/nercel" status ;;
  --restart) stop_all ;;
  --open)    OPEN_BROWSER="1" ;;
  *)         OPEN_BROWSER="${NERCEL_OPEN:-0}" ;;
esac

[ -z "$PY" ] && { err "Python 3.8+ requis (apt install python3)"; exit 1; }
[ "$(id -u)" = "0" ] && { err "Ne lance pas NERCEL en root."; exit 1; }

if port_up "$PORT" || port_up "$EDGE_PORT"; then
  err "Un serveur occupe déjà le port $PORT ou $EDGE_PORT."
  printf "${C}▸${N} Pour arrêter : bash start.sh --stop\n"
  exit 1
fi

info "Démarrage orchestrateur :$PORT"
"$PY" "$HERE/server.py" >>"$LOG_DIR/orchestrator.log" 2>&1 &
info "Démarrage edge NEXUS :$EDGE_PORT"
"$PY" "$HERE/nexusd.py" >>"$LOG_DIR/nexusd.log" 2>&1 &

# attendre que l'API réponde
for i in 1 2 3 4 5 6 7 8; do
  if "$PY" -c "import urllib.request,sys;sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:$PORT/api/health',timeout=1).status==200 else 1)" 2>/dev/null; then
    break
  fi
  sleep 0.5
done

if port_up "$PORT"; then
  ok "NERCEL v7.0 est en ligne"
  printf "  ${B}Dashboard${N}  :  http://127.0.0.1:$PORT/\n"
  printf "  ${B}Edge proxy${N}  :  http://127.0.0.1:$EDGE_PORT/\n"
  printf "  ${B}Docs${N}        :  http://127.0.0.1:$PORT/docs\n"
  printf "  ${B}Données${N}     :  $DATA_DIR\n"
  printf "${C}▸${N} Ouvrir    :  bash start.sh --open   (rien ne s'ouvre tout seul)\n"
  printf "${C}▸${N} Arrêter   :  bash start.sh --stop\n"
  command -v git >/dev/null 2>&1 || printf "  ${R}⚠ git absent — déploiement GitHub désactivé${N}\n"
  command -v z-ai >/dev/null 2>&1 || printf "  ${R}⚠ z-ai absent — GLM désactivé (Pollinations reste OK)${N}\n"
  if [ "$OPEN_BROWSER" = "1" ]; then
    command -v xdg-open >/dev/null 2>&1 && ( sleep 0.5 && xdg-open "http://127.0.0.1:$PORT/" >/dev/null 2>&1 ) &
  fi
else
  err "Le serveur n'a pas démarré. Journal :"
  tail -8 "$LOG_DIR/orchestrator.log" 2>/dev/null | sed 's/^/  /'
  exit 1
fi

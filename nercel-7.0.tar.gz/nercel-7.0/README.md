# ▲ NERCEL v7.0

Écosystème local autonome : orchestrateur HTTP, proxy edge NEXUS, agents,
chat IA, déploiement de paquets et **registre d'options unique** partagé par
le serveur, la CLI et le dashboard. Python 3.8+ stdlib uniquement.

## Démarrage
```bash
bash start.sh            # orchestrateur + edge, 0 navigateur auto
bash start.sh --open     # idem + ouvre le navigateur
bash start.sh --stop
```
Dashboard : http://127.0.0.1:3923/

## CLI
```bash
nercel status
nercel config list                       # toutes les options
nercel config set ui.theme cyber         # thème immédiat
nercel edit .                            # lancer l'éditeur configuré
nercel agents add mon-agent python
nercel ai "résume la config serveur"
nercel deploy app.tar.gz
```

## Registre d'options
Déclaré une fois dans `config.py` → disponible partout.
10 catégories : serveur, editeur, ia, ui, securite, donnees, deploiement,
agents, chat, observabilite. Persistance : `~/.nercel/config.json`.

## Éditeurs supportés
auto, code, vscodium, cursor, vim, nano, micro, emacs, code-server, none.

## Fournisseurs IA
pollinations (défaut, gratuit), glm (z-ai), openai, ollama, none.

Voir `docs.html` ou http://127.0.0.1:3923/docs pour la référence complète.

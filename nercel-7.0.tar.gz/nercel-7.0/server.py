#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NERCEL v7.0 — orchestrateur.

Serveur HTTP autonome (stdlib uniquement) qui expose le dashboard, l'API
de configuration, le lancement d'éditeur, les agents, le chat IA et les
dépôts de paquets. Toute la configuration vient du registre `config.py`.
"""

from __future__ import annotations
import json
import os
import sys
import time
import uuid
import shutil
import socket
import tarfile
import threading
import subprocess
import urllib.request
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import config as C  # noqa: E402

LOG_PATH = os.path.join(C.DATA_DIR, "logs", "orchestrator.log")
AGENTS_PATH = os.path.join(C.DATA_DIR, "agents.json")
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

START_TS = time.time()
_REQUESTS = {"count": 0, "lock": threading.Lock()}


def log(level: str, msg: str) -> None:
    lvl = C.CFG.get("serveur.log_level")
    order = {"debug": 0, "info": 1, "warning": 2, "error": 3}
    if order.get(level, 1) < order.get(lvl, 1):
        return
    line = f"{datetime.now(timezone.utc).strftime('%H:%M:%S')} [{level}] {msg}"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass
    print(line, file=sys.stderr, flush=True)


# --------------------------------------------------------------------------- #
# Agents
# --------------------------------------------------------------------------- #
def _load_agents() -> list:
    try:
        with open(AGENTS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_agents(agents: list) -> None:
    tmp = AGENTS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(agents, f, ensure_ascii=False, indent=2)
    os.replace(tmp, AGENTS_PATH)


def agent_register(name: str, runtime: str | None = None) -> dict:
    runtime = runtime or C.CFG.get("agents.default_runtime")
    ag = {
        "id": uuid.uuid4().hex[:12],
        "name": name,
        "runtime": runtime,
        "status": "idle",
        "created": datetime.now(timezone.utc).isoformat(),
        "heartbeat": datetime.now(timezone.utc).isoformat(),
    }
    agents = _load_agents()
    if len(agents) >= int(C.CFG.get("agents.max_agents")):
        raise RuntimeError("Nombre maximal d'agents atteint")
    agents.append(ag)
    _save_agents(agents)
    return ag


def agent_heartbeat(agent_id: str) -> bool:
    agents = _load_agents()
    for a in agents:
        if a["id"] == agent_id:
            a["heartbeat"] = datetime.now(timezone.utc).isoformat()
            _save_agents(agents)
            return True
    return False


def agent_stop(agent_id: str) -> bool:
    agents = _load_agents()
    for a in agents:
        if a["id"] == agent_id:
            a["status"] = "stopped"
            _save_agents(agents)
            return True
    return False


# --------------------------------------------------------------------------- #
# Éditeur
# --------------------------------------------------------------------------- #
EDITOR_BINARIES = {
    "code": ["code"], "vscodium": ["vscodium"], "cursor": ["cursor"],
    "vim": ["vim"], "nano": ["nano"], "micro": ["micro"],
    "emacs": ["emacs"], "code-server": ["code-server"],
}


def resolve_editor() -> list:
    """Renvoie la commande d'éditeur à lancer, selon la configuration."""
    choice = C.CFG.get("editeur.editor")
    if choice == "none":
        return []
    if choice == "auto":
        for key in ["code", "vscodium", "cursor", "micro", "vim", "nano"]:
            if shutil.which(key):
                return [key]
        return []
    return EDITOR_BINARIES.get(choice, [])


def launch_editor(path: str) -> dict:
    cmd = resolve_editor()
    if not cmd:
        return {"ok": False, "error": "Aucun éditeur configuré ou disponible"}
    target = os.path.abspath(path)
    if not os.path.exists(target):
        return {"ok": False, "error": f"Chemin introuvable : {target}"}
    args = [a for a in C.CFG.get("editeur.args").split() if a]
    full = cmd + args + [target]
    try:
        subprocess.Popen(full, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "command": " ".join(full)}
    except OSError as e:
        return {"ok": False, "error": str(e)}


# --------------------------------------------------------------------------- #
# Chat IA
# --------------------------------------------------------------------------- #
def chat_pollinations(prompt: str) -> str:
    url = "https://text.pollinations.ai/" + urllib.parse.quote(prompt)
    req = urllib.request.Request(url, headers={"User-Agent": "nercel/7.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", "replace")


def chat_glm(prompt: str) -> str:
    """Tente le CLI z-ai, sinon revient à Pollinations."""
    if not shutil.which("z-ai"):
        if C.CFG.get("ia.fallback"):
            return chat_pollinations(prompt)
        raise RuntimeError("z-ai absent et secours désactivé")
    sys_prompt = C.CFG.get("ia.system_prompt")
    try:
        out = subprocess.check_output(
            ["z-ai", "chat", "--prompt", sys_prompt + "\n" + prompt],
            stderr=subprocess.STDOUT, timeout=25)
        return out.decode("utf-8", "replace").strip()
    except (subprocess.SubprocessError, OSError):
        if C.CFG.get("ia.fallback"):
            return chat_pollinations(prompt)
        raise


def chat_reply(prompt: str) -> dict:
    provider = C.CFG.get("ia.provider")
    if provider == "none":
        return {"ok": True, "reply": "IA désactivée (ia.provider = none).",
                "provider": "none"}
    try:
        if provider == "glm":
            reply = chat_glm(prompt)
        elif provider == "openai":
            reply = chat_pollinations(prompt)  # passerelle compatible
        elif provider == "ollama":
            reply = chat_ollama(prompt)
        else:
            reply = chat_pollinations(prompt)
        return {"ok": True, "reply": reply, "provider": provider}
    except Exception as e:
        return {"ok": False, "reply": "", "error": str(e)}


def chat_ollama(prompt: str) -> str:
    body = json.dumps({"model": C.CFG.get("ia.model"),
                       "prompt": prompt, "stream": False}).encode()
    req = urllib.request.Request("http://127.0.0.1:11434/api/generate",
                                 data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read()).get("response", "")


# --------------------------------------------------------------------------- #
# Déploiement
# --------------------------------------------------------------------------- #
def deploy_package(tmp_path: str, name: str) -> dict:
    target = os.path.join(C.DATA_DIR, "apps", name)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if os.path.exists(target):
        shutil.rmtree(target)
    with tarfile.open(tmp_path, "r:gz") as tar:
        tar.extractall(target)
    result = {"ok": True, "app": name, "path": target,
              "files": sum(len(files) for _, _, files in os.walk(target))}
    if C.CFG.get("editeur.open_on_deploy"):
        ed = launch_editor(target)
        result["editor"] = ed
    return result


# --------------------------------------------------------------------------- #
# Métriques
# --------------------------------------------------------------------------- #
def metrics() -> dict:
    import resource
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    with _REQUESTS["lock"]:
        count = _REQUESTS["count"]
    return {
        "uptime_s": int(time.time() - START_TS),
        "requests": count,
        "rss_kb": int(rss),
        "version": "7.0",
        "agents": len(_load_agents()),
    }


# --------------------------------------------------------------------------- #
# Handler HTTP
# --------------------------------------------------------------------------- #
class Handler(BaseHTTPRequestHandler):
    server_version = "nercel/7.0"

    def _send(self, code: int, body: bytes, ctype: str = "application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin",
                         C.CFG.get("securite.cors_origins"))
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code: int, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode(),
                   "application/json")

    def _read_body(self) -> dict:
        n = int(self.headers.get("Content-Length", 0))
        if n == 0:
            return {}
        if n > C.CFG.get("serveur.max_upload_mb") * 1024 * 1024:
            raise ValueError("Téléversement trop volumineux")
        return json.loads(self.rfile.read(n).decode("utf-8", "replace"))

    def log_message(self, fmt, *args):  # journal propre, pas le bruit par défaut
        with _REQUESTS["lock"]:
            _REQUESTS["count"] += 1
        log("debug", f"{self.address_string()} {fmt % args}")

    def do_OPTIONS(self):
        self._send(204, b"")

    # --- GET --------------------------------------------------------------- #
    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        path, q = p.path, urllib.parse.parse_qs(p.query)
        if path == "/" or path == "/index.html":
            return self._serve_file("index.html", "text/html")
        if path == "/app.js":
            return self._serve_file("app.js", "application/javascript")
        if path == "/style.css":
            return self._serve_file("style.css", "text/css")
        if path == "/docs" or path == "/docs.html":
            return self._serve_file("docs.html", "text/html")
        if path == "/api/health":
            return self._json(200, {"status": "ok",
                                    "version": "7.0",
                                    "uptime": int(time.time() - START_TS)})
        if path == "/api/config":
            return self._json(200, {"options": C.CFG.registry(),
                                    "categories": C.categories()})
        if path.startswith("/api/config/"):
            key = path.rsplit("/", 1)[1]
            o = C.get_option(key)
            if not o:
                return self._json(404, {"error": f"Option inconnue : {key}"})
            return self._json(200, C.CFG.describe(key))
        if path == "/api/agents":
            return self._json(200, {"agents": _load_agents()})
        if path == "/api/metrics":
            return self._json(200, metrics())
        self._json(404, {"error": "Route inconnue"})

    def _serve_file(self, name: str, ctype: str):
        fp = os.path.join(HERE, name)
        try:
            with open(fp, "rb") as f:
                body = f.read()
            self._send(200, body, ctype)
        except FileNotFoundError:
            self._json(404, {"error": f"Fichier manquant : {name}"})

    # --- POST -------------------------------------------------------------- #
    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        # le téléversement de paquet est du binaire brut, pas du JSON
        if path.startswith("/api/deploy/upload"):
            return self._handle_upload(path)
        try:
            body = self._read_body()
        except (ValueError, json.JSONDecodeError) as e:
            return self._json(400, {"error": str(e)})
        if path == "/api/config":
            key, value = body.get("key"), body.get("value")
            if not key:
                return self._json(400, {"error": "Champ 'key' requis"})
            ok, msg = C.CFG.set(key, value)
            return self._json(200 if ok else 400, {"ok": ok, "message": msg})
        if path.startswith("/api/config/") and path.endswith("/reset"):
            key = path.split("/")[3]
            ok, msg = C.CFG.reset(key)
            return self._json(200 if ok else 404, {"ok": ok, "message": msg})
        if path == "/api/editor/launch":
            p = body.get("path", HERE)
            return self._json(200, launch_editor(p))
        if path == "/api/agents":
            name = body.get("name", "agent")
            runtime = body.get("runtime")
            try:
                ag = agent_register(name, runtime)
                log("info", f"Agent créé : {ag['id']} ({name})")
                return self._json(201, ag)
            except RuntimeError as e:
                return self._json(409, {"error": str(e)})
        if path.startswith("/api/agents/") and path.endswith("/heartbeat"):
            aid = path.split("/")[3]
            return self._json(200 if agent_heartbeat(aid) else 404, {"ok": True})
        if path.startswith("/api/agents/") and path.endswith("/stop"):
            aid = path.split("/")[3]
            return self._json(200 if agent_stop(aid) else 404, {"ok": True})
        if path == "/api/chat":
            prompt = body.get("prompt", "").strip()
            if not prompt:
                return self._json(400, {"error": "Champ 'prompt' requis"})
            return self._json(200, chat_reply(prompt))
        if path == "/api/deploy":
            name = body.get("name", "app")
            tmp = body.get("tmp_path")
            if not tmp or not os.path.exists(tmp):
                return self._json(400, {"error": "Champ 'tmp_path' requis"})
            return self._json(200, deploy_package(tmp, name))
        self._json(404, {"error": "Route inconnue"})

    def _handle_upload(self, path: str):
        """Téléversement brut d'un paquet .tar.gz depuis le navigateur."""
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        name = (qs.get("name", ["app"])[0]).replace("/", "_")
        n = int(self.headers.get("Content-Length", 0))
        limit = C.CFG.get("serveur.max_upload_mb") * 1024 * 1024
        if n == 0 or n > limit:
            return self._json(400, {"error": "Téléversement vide ou trop volumineux"})
        tmp_dir = os.path.join(C.DATA_DIR, "uploads")
        os.makedirs(tmp_dir, exist_ok=True)
        tmp_path = os.path.join(tmp_dir, "%s-%d.tar.gz" % (name, int(time.time())))
        with open(tmp_path, "wb") as f:
            f.write(self.rfile.read(n))
        try:
            return self._json(200, deploy_package(tmp_path, name))
        finally:
            try: os.remove(tmp_path)
            except OSError: pass


# --------------------------------------------------------------------------- #
# Démarrage
# --------------------------------------------------------------------------- #
def main() -> int:
    port = int(C.CFG.get("serveur.port"))
    host = C.CFG.get("serveur.host")
    try:
        srv = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        log("error", f"Impossible d'écouter sur {host}:{port} — {e}")
        return 1
    pidfile = os.path.join(C.DATA_DIR, "nercel.pid")
    with open(pidfile, "w") as f:
        f.write(str(os.getpid()))
    log("info", f"Orchestrateur en écoute sur http://{host}:{port}/")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log("info", "Arrêt demandé")
    finally:
        srv.shutdown()
        os.remove(pidfile)
    return 0


if __name__ == "__main__":
    sys.exit(main())

/* NERCEL v7.0 — logique du dashboard. Aucune dépendance externe. */
"use strict";
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const api = async (method, route, body) => {
  const opt = {method, headers:{}};
  if (body !== undefined && body !== null && !(body instanceof Blob)) {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  } else if (body instanceof Blob) {
    opt.body = body;
  }
  const r = await fetch(route, opt);
  return r.json().catch(() => ({error:"réponse invalide"}));
};

// --- application des options UI ------------------------------------------- //
function applyUI(opt){
  const get = k => (opt.find(o => o.key===k) || {}).value;
  document.documentElement.dataset.theme = get("ui.theme") || "dark";
  document.documentElement.dataset.density = get("ui.density") || "confortable";
  document.documentElement.dataset.sidebar = get("ui.sidebar_collapsed") ? "0" : "1";
  document.documentElement.dataset.anim = get("ui.animations") === false ? "0" : "1";
  if (get("ui.accent")) document.documentElement.style.setProperty("--accent", get("ui.accent"));
  if (get("ui.font_size")) document.documentElement.style.setProperty("--font", get("ui.font_size")+"px");
}

// --- navigation ----------------------------------------------------------- //
function nav(view){
  $$(".view").forEach(v => v.classList.add("hidden"));
  $("#view-"+view).classList.remove("hidden");
  $$(".navlink").forEach(a => a.classList.toggle("active", a.dataset.view===view));
  if (view === "docs") loadDocs();
}
$$(".navlink").forEach(a => a.addEventListener("click", () => nav(a.dataset.view)));

// --- tableau de bord ------------------------------------------------------ //
async function loadStats(){
  const [h, m] = await Promise.all([api("GET","/api/health"), api("GET","/api/metrics")]);
  $("#health-dot").textContent = h.status === "ok" ? "en ligne" : "hors ligne";
  $("#health-dot").style.background = h.status === "ok" ? "var(--ok)" : "var(--err)";
  const card = (n,l) => `<div class="stat"><div class="n">${n}</div><div class="l">${l}</div></div>`;
  $("#stats").innerHTML = [
    card(m.version ? "v"+m.version : "—", "version"),
    card(m.uptime_s || 0, "uptime (s)"),
    card(m.requests || 0, "requêtes"),
    card(m.agents || 0, "agents"),
    card(Math.round((m.rss_kb||0)/1024)+" M", "mémoire"),
  ].join("");
}

// --- options -------------------------------------------------------------- //
let OPTS = [];
function field(o){
  const val = o.secret && o.value ? "••••" : o.value;
  if (o.type === "bool")
    return `<label><input type="checkbox" data-k="${o.key}" ${o.value ? "checked":""}></label>`;
  if (o.type === "choice")
    return `<select data-k="${o.key}">${(o.choices||[]).map(c=>`<option ${c===o.value?"selected":""}>${c}</option>`).join("")}</select>`;
  if (o.type === "int")
    return `<input type="number" data-k="${o.key}" value="${val}" min="${o.min??""}" max="${o.max??""}">`;
  if (o.type === "color")
    return `<input type="color" data-k="${o.key}" value="${val}">`;
  return `<input type="text" data-k="${o.key}" value="${val}" ${o.secret?"type=password":""}>`;
}
async function loadOptions(){
  const d = await api("GET","/api/config");
  OPTS = d.options || [];
  applyUI(OPTS);
  $("#opt-count").textContent = OPTS.length;
  let html = "", cat = null;
  for (const o of OPTS){
    if (o.category !== cat){ cat = o.category; html += `<div class="cat-title">${cat}</div>`; }
    html += `<div class="row"><div><div><b>${o.key}</b></div><div class="desc">${o.desc}</div></div><div>${field(o)}</div></div>`;
  }
  $("#options").innerHTML = html;
  $$("[data-k]").forEach(el => {
    const ev = el.type === "checkbox" ? "change" : el.type === "color" ? "change" : "change";
    el.addEventListener(ev, async () => {
      const v = el.type === "checkbox" ? el.checked
              : el.type === "number" ? Number(el.value) : el.value;
      const r = await api("POST","/api/config",{key:el.dataset.k, value:v});
      if (r.ok){ reloadUI(); flash(el, "ok"); }
      else { flash(el, "err"); alert(r.message || "échec"); }
    });
  });
}
async function reloadUI(){
  const d = await api("GET","/api/config");
  OPTS = d.options || []; applyUI(OPTS);
}
function flash(el, kind){
  el.style.outline = kind === "ok" ? "2px solid var(--ok)" : "2px solid var(--err)";
  setTimeout(() => el.style.outline = "", 600);
}

// --- agents --------------------------------------------------------------- //
async function loadAgents(){
  const d = await api("GET","/api/agents");
  const tb = $("#agents-tbl tbody");
  tb.innerHTML = (d.agents||[]).map(a =>
    `<tr><td class="mono">${a.id}</td><td>${a.name}</td><td>${a.runtime}</td><td>${a.status}</td>
      <td><button class="ghost" data-stop="${a.id}">arrêter</button></td></tr>`).join("");
  $$("[data-stop]").forEach(b => b.onclick = async () => {
    await api("POST",`/api/agents/${b.dataset.stop}/stop`,{});
    loadAgents();
  });
}
$("[data-act=add-agent]").onclick = async () => {
  const name = $("#agent-name").value.trim();
  if (!name) return alert("Donnez un nom à l'agent.");
  await api("POST","/api/agents",{name, runtime:$("#agent-runtime").value || null});
  $("#agent-name").value = ""; loadAgents();
};

// --- chat ----------------------------------------------------------------- //
$("#chat-form").onsubmit = async (e) => {
  e.preventDefault();
  const q = $("#chat-input").value.trim();
  if (!q) return;
  log("user", q); $("#chat-input").value = "";
  const r = await api("POST","/api/chat",{prompt:q});
  log("bot", r.ok ? r.reply : "✗ " + (r.error || "échec"));
};
function log(who, txt){
  $("#chat-log").insertAdjacentHTML("beforeend",
    `<div class="msg ${who}">${txt.replace(/</g,"&lt;")}</div>`);
  $("#chat-log").scrollTop = $("#chat-log").scrollHeight;
}

// --- éditeur -------------------------------------------------------------- //
$("#edit-form").onsubmit = async (e) => {
  e.preventDefault();
  const path = $("#edit-path").value.trim() || ".";
  const r = await api("POST","/api/editor/launch",{path});
  $("#edit-result").textContent = r.ok ? "✓ " + r.command : "✗ " + (r.error || "échec");
};
$("[data-act=edit-here]").onclick = () => api("POST","/api/editor/launch",{path:"."}).then(r =>
  alert(r.ok ? "Éditeur lancé : " + r.command : "✗ " + (r.error || "aucun éditeur disponible")));

// --- déploiement ---------------------------------------------------------- //
$("[data-act=deploy]").onclick = async () => {
  const f = $("#deploy-file").files[0];
  if (!f) return alert("Choisissez un fichier .tar.gz.");
  $("#deploy-result").textContent = "Déploiement en cours…";
  const name = f.name.replace(/\.(tar\.gz|tgz)$/,"");
  const r = await api("POST",`/api/deploy/upload?name=${encodeURIComponent(name)}`, f);
  $("#deploy-result").textContent = r.ok
    ? `✓ déployé : ${r.app} (${r.files} fichiers)`
    : "✗ " + (r.error || "échec");
};

// --- docs ----------------------------------------------------------------- //
async function loadDocs(){
  if ($("#docs-card").dataset.loaded) return;
  const r = await fetch("/docs");
  const html = await r.text();
  // extraire le <main> des docs
  const m = html.match(/<body[^>]*>([\s\S]*)<\/body>/);
  $("#docs-card").innerHTML = m ? m[1] : html;
  $("#docs-card").dataset.loaded = "1";
}

// --- actions diverses ----------------------------------------------------- //
$("[data-act=reload-config]").onclick = loadOptions;
$("[data-act=backup]").onclick = () => alert("Sauvegarde planifiée (backup_on_start géré au démarrage).");
$("[data-act=restart]").onclick = () => alert("Utilisez : bash start.sh --restart");

// --- init ----------------------------------------------------------------- //
(async () => {
  await loadOptions();
  await loadStats();
  await loadAgents();
  $("#chat-provider").textContent = (OPTS.find(o=>o.key==="ia.provider")||{}).value || "—";
  setInterval(loadStats, 5000);
})();

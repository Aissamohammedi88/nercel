# Nercel v1.0 — Plateforme de déploiement locale (Vercel-like)

> Un **Vercel-like 100% local**, en Python stdlib (zéro dépendance pip),
> inspiré **KDE Plasma** + **SpaceX Electron**. Déployer un projet Node/Rust/Go/Python/statique
> en un upload ZIP ou une URL GitHub, avec build automatique, port assigné, PID persisté en SQLite,
> et reverse proxy edge sur `http://127.0.0.1:8765/<nom>/`.

## Architecture

```
[ Utilisateur ]
      │
      ▼
[ Dashboard Plasma-style (index.html) ] ──(API REST)──┐
                                           │
                                           ▼
                             [ Orchestrator (nercel.py, port 3923) ]
                                           │
                    ┌──────────────────────┼──────────────────────┐
                    ▼                      ▼                      ▼
             [ Module Build ]       [ Module Deploy ]       [ SQLite deploy.db ]
             (détecte type,         (trouve port libre,
              compile, log)          lance subprocess,
                                           │                  PID + port)
                                           ▼
                             [ NEXUS Edge (nexusd.py, port 8765) ]
                             (reverse proxy → 127.0.0.1:<port>)
```

## Les 5 modules

| # | Module              | Fichier          | Rôle |
|---|---------------------|------------------|------|
| 1 | **Dashboard**       | `index.html`     | Interface Plasma-style : upload ZIP, URL GitHub, liste des projets, statut temps réel, logs SSE, boutons Stop/Restart/Delete |
| 2 | **Orchestrateur**   | `nercel.py`      | API REST + SQLite + threads de build/deploy |
| 3 | **Build**           | `build_project()` dans `nercel.py` | Détection auto : `package.json` → `npm install && npm run build`, `Cargo.toml` → `cargo build --release`, `go.mod` → `go build`, `requirements.txt` → `pip install -r`, `index.html` seul → statique |
| 4 | **Deploy**          | `deploy_project()` dans `nercel.py` | Trouve port libre (3001-3999), lance subprocess, capture PID, persiste SQLite, refuse root |
| 5 | **DNS/Routage**     | `nexusd.py`      | Reverse proxy port 8765 : `/<nom>/...` → `127.0.0.1:<port>/...` + page d'accueil listant les projets |

## Base de données (SQLite)

Fichier unique `~/.nercel/deploy.db`, table `projects` :

| Colonne         | Type    | Description                                  |
|-----------------|---------|----------------------------------------------|
| `id`            | INTEGER | AUTOINCREMENT                                |
| `name`          | TEXT    | Nom unique du projet                         |
| `path`          | TEXT    | Chemin local absolu                          |
| `port`          | INTEGER | Port assigné (3001-3999)                     |
| `pid`           | INTEGER | PID du processus serveur                     |
| `status`        | TEXT    | `building` / `running` / `error` / `stopped` |
| `project_type`  | TEXT    | `node` / `rust` / `go` / `python` / `static` |
| `created_at`    | TEXT    | ISO timestamp                                |

## API HTTP (orchestrateur, port 3923)

| Endpoint                          | Méthode | Description |
|-----------------------------------|---------|-------------|
| `/`                               | GET     | Dashboard HTML |
| `/api/health`                     | GET     | `{ok, version, uptime}` |
| `/api/status`                     | GET     | Liste tous les projets |
| `/api/projects/<name>`            | GET     | Détail d'un projet |
| `/api/deploy`                     | POST    | Upload multipart `.zip` OU JSON `{github_url, name}` — déclenche build+deploy asynchrone, renvoie `202` + `log_url` + `edge_url` |
| `/api/stop/<name>`                | POST    | Arrête le serveur (SIGTERM puis SIGKILL) |
| `/api/restart/<name>`             | POST    | Stop + redéploiement sur nouveau port |
| `/api/projects/<name>`            | DELETE  | Stop + suppression fichiers + suppression ligne DB |
| `/api/logs/<name>`                | GET     | Contenu complet de `~/.nercel/logs/<name>.log` |
| `/api/logs/<name>/stream`         | GET     | **SSE** — log lines en temps réel jusqu'à fin de build |

## Edge proxy (port 8765)

| URL                          | Résultat |
|------------------------------|----------|
| `http://127.0.0.1:8765/`     | Homepage listant tous les projets en `running` (cliquables) |
| `http://127.0.0.1:8765/<nom>/`      | Proxy → `127.0.0.1:<port>/` |
| `http://127.0.0.1:8765/<nom>/<path>`| Proxy → `127.0.0.1:<port>/<path>` |
| `ws://127.0.0.1:8765/<nom>/...`     | (best-effort) WebSocket TCP splice |

## Types de projets supportés

| Marqueur              | Type     | Build                                       | Run                                |
|-----------------------|----------|---------------------------------------------|------------------------------------|
| `package.json`        | node     | `npm install` (+ `npm run build` si script) | `npm start` ou `node <main>`       |
| `Cargo.toml`          | rust     | `cargo build --release`                     | `./target/release/<bin>`           |
| `go.mod`              | go       | `go build -o nercel-app .`                  | `./nercel-app`                     |
| `requirements.txt`    | python   | `pip install --user -r requirements.txt`    | `python3 app.py/main.py/wsgi.py`   |
| `pyproject.toml`      | python   | `pip install --user -e .`                   | `python3 -m uvicorn app:app --port <port>` |
| `Dockerfile`          | docker   | `docker build -t nercel-<name> .`           | `docker run --rm -p <port>:80 ...` |
| `index.html` (seul)   | static   | (aucun)                                     | `python3 -m http.server <port>`    |

## Règles d'or (implémentées)

1. **Un projet = un port.** Jamais de réutilisation. `find_free_port()` scanne 3001→3999, évite les ports déjà en base et ceux déjà bindés par le système.
2. **Logs temps réel.** Chaque projet a `~/.nercel/logs/<name>.log` alimenté en streaming par `subprocess.Popen(stdout=log_file)`. Le dashboard consomme en SSE via `/api/logs/<name>/stream`.
3. **Jamais root.** `nercel.py` et `nexusd.py` quittent immédiatement si `os.geteuid() == 0`. `install.sh` refuse aussi root.
4. **Cleanup sur échec.** `deploy_pipeline()` supprime le dossier projet si le build ou le deploy échoue.

## Installation

```bash
tar -xzf nercel-1.0.tar.gz -C nercel && cd nercel
bash install.sh
```

L'installer :
- refuse root,
- détecte Python 3.8+ (utilise `python3` ou `python`),
- symlink `nercel` et `nexusd` dans `~/.local/bin`,
- crée `~/.nercel/{projects,logs}`,
- lance les deux processus en arrière-plan,
- écrit les PID dans `~/.nercel/{nercel,nexusd}.pid`.

Outils optionnels pour activer plus de types de projets : `npm`, `cargo`, `go`, `docker`.

## Utilisation

1. Ouvre `http://127.0.0.1:3923/` dans Firefox/Chrome.
2. Clique **+ Nouveau Projet**.
3. Choisis **.zip local** ou colle une **URL GitHub**.
4. Donne un nom (ou laisse auto-généré).
5. Clique **🚀 Déployer**.
6. La fenêtre **Logs** s'ouvre automatiquement avec streaming temps réel du build.
7. Une fois `running`, le bouton **↗ Ouvrir via NEXUS Edge** t'envoie sur `http://127.0.0.1:8765/<nom>/`.

## Arrêter

```bash
kill $(cat ~/.nercel/nercel.pid) $(cat ~/.nercel/nexusd.pid)
```

L'orchestrateur, à l'arrêt propre (Ctrl+C), tue aussi tous les projets `running` et les marque `stopped` en base.

## Sécurité

- 100% local, aucun cloud, aucune télémétrie.
- Refuse root sur les deux serveurs.
- Le proxy edge n'écoute que sur `127.0.0.1` (pas d'exposition réseau).
- Les projets sont lancés avec l'utilisateur courant (jamais root).
- Aucune exécution de code arbitraire côté orchestrateur — seul le code du projet lui-même s'exécute (comme tout Vercel-like).

## Limitations actuelles

- Pas de TLS (prévu pour rester local).
- Pas de gestion d'environnement `.env` par projet (à venir).
- Le proxy WebSocket est best-effort (TCP splice brut, pas de ping/pong).
- Pas de build parallèle pour monorepos.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NERCEL v7.0 — proxy edge NEXUS.

Écouté sur `serveur.edge_port`, il transpose chaque requête vers
l'orchestrateur (127.0.0.1:serveur.port) en ajoutant les en-têtes
X-Forwarded-* Utile pour exposer un point d'entrée unique ou pour
mutualiser les journaux. Stdlib uniquement.
"""

from __future__ import annotations
import os
import sys
import time
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import config as C  # noqa: E402

START = time.time()


class EdgeHandler(BaseHTTPRequestHandler):
    server_version = "nexusd/7.0"

    def _forward(self, method: str):
        port = int(C.CFG.get("serveur.port"))
        url = "http://127.0.0.1:%d%s" % (port, self.path)
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n) if n else None
        headers = {k: v for k, v in self.headers.items()
                   if k.lower() not in ("host", "content-length")}
        headers["X-Forwarded-For"] = self.address_string()
        headers["X-Forwarded-Proto"] = "http"
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
                self.send_response(resp.status)
                for k, v in resp.getheaders():
                    if k.lower() not in ("transfer-encoding", "connection"):
                        self.send_header(k, v)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            msg = ("proxy edge : cible injoignable — %s" % e).encode()
            self.send_response(502)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)

    def do_GET(self):    self._forward("GET")
    def do_POST(self):   self._forward("POST")
    def do_OPTIONS(self):
        self.send_response(204); self.end_headers()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s [nexusd] %s\n" %
                         (time.strftime("%H:%M:%S"), fmt % args))


def main() -> int:
    port = int(C.CFG.get("serveur.edge_port"))
    host = C.CFG.get("serveur.host")
    try:
        srv = ThreadingHTTPServer((host, port), EdgeHandler)
    except OSError as e:
        sys.stderr.write("nexusd : impossible d'écouter sur %s:%d — %s\n"
                         % (host, port, e))
        return 1
    pidfile = os.path.join(C.DATA_DIR, "nexusd.pid")
    with open(pidfile, "w") as f:
        f.write(str(os.getpid()))
    sys.stderr.write("nexusd : edge en écoute sur http://%s:%d/ → 127.0.0.1:%d\n"
                     % (host, port, int(C.CFG.get("serveur.port"))))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.shutdown()
        os.remove(pidfile)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Nercel v1.0 — Local Vercel-like deploy platform.

Single-file orchestrator (port 3923) that bundles:
  - Module 2: HTTP API + SQLite deploy.db
  - Module 3: build_project() — auto-detects Node/Rust/Go/Python/static
  - Module 4: deploy_project() — finds free port, launches subprocess,
              captures PID, persists to DB, refuses root

The edge proxy (Module 5) lives in nexusd.py (port 8765).
The dashboard (Module 1) lives in index.html, served by this orchestrator.

Stdlib only, like Kemus.
"""
import os
import sys
import json
import sqlite3
import subprocess
import shutil
import zipfile
import signal
import time
import threading
import re
import urllib.request
import urllib.parse
import http.server
import socketserver
import socket
import hashlib
from pathlib import Path
from datetime import datetime
from html import escape

VERSION = "1.0.0"
PORT = 3923
NEXUS_PORT = 8765
DATA_DIR = Path(os.path.expanduser("~/.nercel"))
PROJECTS_DIR = DATA_DIR / "projects"
LOGS_DIR = DATA_DIR / "logs"
DB_PATH = DATA_DIR / "deploy.db"
INDEX_HTML = Path(__file__).resolve().parent / "index.html"

PORT_MIN = 3001
PORT_MAX = 3999
VALID_NAME = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{1,62}$")

# =============================================================================
# Database (Module 2 — persistence layer)
# =============================================================================

def db_init() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS projects (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT UNIQUE NOT NULL,
            path         TEXT NOT NULL,
            port         INTEGER,
            pid          INTEGER,
            status       TEXT NOT NULL,
            project_type TEXT,
            created_at   TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def db_list_projects() -> list[dict]:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM projects ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_get_project(name: str) -> dict | None:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    r = conn.execute("SELECT * FROM projects WHERE name = ?", (name,)).fetchone()
    conn.close()
    return dict(r) if r else None


def db_upsert(name: str, **fields) -> None:
    """Update an existing project row, or insert a new one.

    Two-step UPDATE-then-INSERT (instead of INSERT ... ON CONFLICT) so that
    NOT NULL columns (like `path`) are not violated when upserting only a
    subset of fields on an existing row.
    """
    if not fields:
        return
    conn = sqlite3.connect(str(DB_PATH))
    sets = ",".join([f"{c}=?" for c in fields])
    vals = list(fields.values()) + [name]
    cur = conn.execute(f"UPDATE projects SET {sets} WHERE name = ?", vals)
    if cur.rowcount == 0:
        # Row does not exist yet — caller must provide all required columns.
        cols = list(fields.keys()) + ["name"]
        placeholders = ",".join(["?"] * len(cols))
        all_vals = list(fields.values()) + [name]
        conn.execute(
            f"INSERT INTO projects ({','.join(cols)}) VALUES ({placeholders})",
            all_vals,
        )
    conn.commit()
    conn.close()


def db_delete(name: str) -> None:
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("DELETE FROM projects WHERE name = ?", (name,))
    conn.commit()
    conn.close()


# =============================================================================
# Module 3 — Build
# =============================================================================

def detect_project_type(path: Path) -> dict | None:
    """Detect project type from files present in `path`.

    Returns a dict describing build steps and the run command, or None
    if no known marker file is present.
    """
    if not path.is_dir():
        return None
    files = {f.name for f in path.iterdir() if f.is_file()}

    if "package.json" in files:
        try:
            pkg = json.loads((path / "package.json").read_text(encoding="utf-8"))
        except Exception:
            pkg = {}
        scripts = pkg.get("scripts", {}) or {}
        steps = [("npm install --no-audit --no-fund", "Installing Node dependencies")]
        if "build" in scripts:
            steps.append(("npm run build", "Building Node project"))
        if "start" in scripts:
            run = "npm start"
        else:
            main = pkg.get("main", "server.js")
            run = f"node {main}"
        return {"type": "node", "build_steps": steps, "run_cmd": run}

    if "Cargo.toml" in files:
        bin_name = "app"
        try:
            in_pkg = False
            for line in (path / "Cargo.toml").read_text(encoding="utf-8").splitlines():
                ls = line.strip()
                if ls.startswith("[") and "package" in ls:
                    in_pkg = True
                    continue
                if ls.startswith("["):
                    in_pkg = False
                    continue
                if in_pkg:
                    m = re.match(r'^name\s*=\s*"([^"]+)"', ls)
                    if m:
                        bin_name = m.group(1).replace("-", "_")
                        break
        except Exception:
            pass
        return {
            "type": "rust",
            "build_steps": [("cargo build --release", "Building Rust project")],
            "run_cmd": f"./target/release/{bin_name}",
        }

    if "go.mod" in files:
        return {
            "type": "go",
            "build_steps": [("go build -o nercel-app .", "Building Go project")],
            "run_cmd": "./nercel-app",
        }

    if "requirements.txt" in files:
        target = next((f for f in ["app.py", "main.py", "wsgi.py", "server.py"] if f in files), "app.py")
        return {
            "type": "python",
            "build_steps": [
                ("python3 -m venv .nercel-venv", "Creating project virtualenv"),
                (".nercel-venv/bin/pip install --quiet --disable-pip-version-check -r requirements.txt",
                 "Installing Python dependencies"),
            ],
            "run_cmd": f".nercel-venv/bin/python {target}",
        }

    if "pyproject.toml" in files:
        return {
            "type": "python",
            "build_steps": [
                ("python3 -m venv .nercel-venv", "Creating project virtualenv"),
                (".nercel-venv/bin/pip install --quiet --disable-pip-version-check -e .",
                 "Installing Python project"),
            ],
            "run_cmd": ".nercel-venv/bin/python -m uvicorn app:app --port {port}",
        }

    if "Dockerfile" in files:
        return {
            "type": "docker",
            "build_steps": [("docker build -t nercel-{name} .", "Building Docker image")],
            "run_cmd": "docker run --rm -p {port}:80 nercel-{name}",
        }

    if "index.html" in files:
        return {"type": "static", "build_steps": [], "run_cmd": None}

    return None


def _run_step(cmd: str, cwd: Path, fh, label: str) -> bool:
    fh.write(f"\n▶ {label}\n  $ {cmd}\n")
    fh.flush()
    try:
        proc = subprocess.Popen(
            cmd,
            shell=True,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        for line in proc.stdout:
            fh.write(line)
            fh.flush()
        proc.wait()
        if proc.returncode != 0:
            fh.write(f"\n✗ Build step failed (exit {proc.returncode})\n")
            return False
        fh.write(f"✓ {label} — OK\n")
        return True
    except Exception as e:
        fh.write(f"\n✗ Exception during step: {e}\n")
        return False


def build_project(name: str, path: Path, log_path: Path) -> tuple[bool, dict | None]:
    """Run the build for `name` at `path`, writing logs to `log_path`.

    Returns (success, project_info) where project_info describes type + run_cmd.
    On failure the caller should remove the project directory (golden rule #4).
    """
    info = detect_project_type(path)
    if not info:
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(f"Nercel Build — {name}\n")
            f.write(f"Started: {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n")
            f.write("✗ Cannot detect project type.\n")
            f.write("  Expected one of: package.json, Cargo.toml, go.mod, "
                    "requirements.txt, pyproject.toml, Dockerfile, index.html\n")
        return False, None

    with open(log_path, "w", encoding="utf-8") as f:
        f.write(f"Nercel Build — {name}\n")
        f.write(f"Type detected: {info['type']}\n")
        f.write(f"Started: {datetime.now().isoformat()}\n")
        f.write("=" * 60 + "\n")
        if not info["build_steps"]:
            f.write("ℹ Static project — no build step required.\n")
        for cmd, label in info["build_steps"]:
            cmd_named = cmd.replace("{name}", name)
            if not _run_step(cmd_named, path, f, label):
                return False, info
    return True, info


# =============================================================================
# Module 4 — Deploy
# =============================================================================

def find_free_port() -> int:
    used = {p["port"] for p in db_list_projects() if p["port"]}
    for port in range(PORT_MIN, PORT_MAX + 1):
        if port in used:
            continue
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"No free port in [{PORT_MIN}, {PORT_MAX}]")


def _build_run_cmd(info: dict, name: str, port: int, path: Path) -> str:
    """Materialize the run command for the given project type and port."""
    if info["type"] == "static":
        return f"python3 -m http.server {port} --bind 127.0.0.1 --directory {path}"
    template = info["run_cmd"] or ""
    cmd = template.format(name=name, port=port)
    # For Node and Go, prefer env var PORT if the user didn't write {port}
    if info["type"] == "node" and "{port}" not in template:
        cmd = f"PORT={port} " + cmd
    if info["type"] == "rust" and "{port}" not in template:
        cmd = cmd + f" --port {port}"
    return cmd


def deploy_project(name: str, path: Path, info: dict, port: int, log_path: Path) -> tuple[bool, int | None]:
    """Launch the project server on `port`. Returns (success, pid)."""
    cmd = _build_run_cmd(info, name, port, path)
    env = os.environ.copy()
    env["PORT"] = str(port)
    env["NERCEL_PROJECT"] = name

    with open(log_path, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 60 + "\n")
        f.write(f"▶ Deploy — port {port}\n  $ {cmd}\n")
        f.flush()

    # Stream the project's stdout/stderr into the same log file (append mode).
    out_fh = open(log_path, "a", encoding="utf-8", buffering=1)
    try:
        proc = subprocess.Popen(
            cmd,
            shell=True,
            cwd=str(path),
            stdout=out_fh,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,  # detach from this orchestrator process group
        )
    except Exception as e:
        out_fh.close()
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n✗ Deploy exception: {e}\n")
        return False, None

    # Give the project a moment to bind its port; if it dies immediately, report error.
    time.sleep(1.0)
    if proc.poll() is not None:
        out_fh.close()
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n✗ Process exited immediately with code {proc.returncode}\n")
        return False, None

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"✓ Process running — PID={proc.pid}, port={port}\n")
        f.write(f"  Access via edge proxy: http://127.0.0.1:{NEXUS_PORT}/{name}/\n")
    return True, proc.pid


def stop_project(name: str) -> bool:
    """Stop the project's running process (golden rule #1: kill the PID)."""
    p = db_get_project(name)
    if not p or not p["pid"]:
        return False
    pid = p["pid"]
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(0.4)
        try:
            os.kill(pid, 0)
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return True
    except ProcessLookupError:
        return True
    except PermissionError:
        return False


# =============================================================================
# Upload / GitHub fetch helpers
# =============================================================================

def parse_multipart(body: bytes, boundary: str) -> dict[str, tuple[str | None, bytes]]:
    """Minimal multipart/form-data parser. Returns {field: (filename, content)}."""
    sep = b"--" + boundary.encode("utf-8")
    out: dict[str, tuple[str | None, bytes]] = {}
    for raw in body.split(sep):
        raw = raw.strip(b"\r\n")
        if not raw or raw == b"--":
            continue
        try:
            header_block, _, body_block = raw.partition(b"\r\n\r\n")
        except ValueError:
            continue
        headers = header_block.decode("utf-8", errors="replace")
        m = re.search(r'name="([^"]+)"(?:;\s*filename="([^"]*)")?', headers)
        if not m:
            continue
        field = m.group(1)
        filename = m.group(2)
        out[field] = (filename, body_block.rstrip(b"\r\n"))
    return out


def slugify(name: str) -> str:
    name = name.lower().strip()
    name = re.sub(r"[^a-z0-9_-]+", "-", name).strip("-")
    return name or "project"


def github_archive_url(repo_url: str) -> tuple[str, str]:
    """Convert a GitHub repo URL into (archive_url, slug_name)."""
    m = re.match(r"^https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$", repo_url.strip())
    if not m:
        raise ValueError("URL GitHub invalide. Attendu: https://github.com/<owner>/<repo>")
    owner, repo = m.group(1), m.group(2)
    slug = slugify(f"{repo}-{owner}")
    return f"https://github.com/{owner}/{repo}/archive/refs/heads/main.tar.gz", slug


# =============================================================================
# Async deploy pipeline (build + deploy run in a worker thread)
# =============================================================================

def deploy_pipeline(name: str, source: Path, source_kind: str) -> None:
    """Run the full build+deploy pipeline in background.

    `source` is the uploaded zip path or the downloaded github tarball.
    `source_kind` is 'zip' or 'github'.
    """
    project_dir = PROJECTS_DIR / name
    log_path = LOGS_DIR / f"{name}.log"
    db_upsert(
        name,
        path=str(project_dir),
        status="building",
        port=None,
        pid=None,
        project_type=None,
        created_at=datetime.now().isoformat(timespec="seconds"),
    )
    try:
        # Extract
        if project_dir.exists():
            shutil.rmtree(project_dir)
        project_dir.mkdir(parents=True)
        if source_kind == "zip":
            with zipfile.ZipFile(source) as zf:
                # Strip a top-level dir if present (typical of GitHub zip downloads)
                names = zf.namelist()
                if names and "/" in names[0]:
                    top = names[0].split("/", 1)[0]
                    if all(n.startswith(top + "/") or n == top + "/" for n in names):
                        for member in zf.infolist():
                            target = member.filename.split("/", 1)
                            if len(target) == 2 and target[1]:
                                member.filename = target[1]
                                zf.extract(member, project_dir)
                    else:
                        zf.extractall(project_dir)
                else:
                    zf.extractall(project_dir)
        elif source_kind == "github":
            import tarfile
            with tarfile.open(source, "r:gz") as tf:
                members = tf.getmembers()
                if members and "/" in members[0].name:
                    top = members[0].name.split("/", 1)[0]
                    for m in members:
                        parts = m.name.split("/", 1)
                        if len(parts) == 2 and parts[1]:
                            m.name = parts[1]
                            tf.extract(m, project_dir)
                else:
                    tf.extractall(project_dir)

        # Build
        ok, info = build_project(name, project_dir, log_path)
        if not ok:
            db_upsert(name, status="error")
            # Golden rule #4: cleanup on build failure
            shutil.rmtree(project_dir, ignore_errors=True)
            return

        # Find port + deploy
        port = find_free_port()
        ok, pid = deploy_project(name, project_dir, info, port, log_path)
        if not ok:
            db_upsert(name, status="error")
            shutil.rmtree(project_dir, ignore_errors=True)
            return
        db_upsert(
            name,
            status="running",
            port=port,
            pid=pid,
            project_type=info["type"],
        )
    except Exception as e:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n✗ Pipeline error: {e}\n")
        db_upsert(name, status="error")


# =============================================================================
# HTTP handler (Module 2 — orchestrator API)
# =============================================================================

class NercelHandler(http.server.BaseHTTPRequestHandler):
    server_version = f"Nercel/{VERSION}"

    def log_message(self, fmt, *args):
        sys.stderr.write(f"[nercel] {self.address_string()} {fmt % args}\n")

    # --- helpers ---------------------------------------------------------

    def _send_json(self, code: int, obj) -> None:
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, code: int, text: str, ctype: str = "text/plain; charset=utf-8") -> None:
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> bytes:
        ln = int(self.headers.get("Content-Length", "0") or "0")
        return self.rfile.read(ln) if ln > 0 else b""

    # --- routing ---------------------------------------------------------

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/" or path == "/index.html":
            return self._serve_dashboard()
        if path == "/api/health":
            return self._send_json(200, {"ok": True, "version": VERSION, "uptime": time.time() - START_TIME})
        if path == "/api/status":
            return self._send_json(200, {"projects": db_list_projects()})
        m = re.match(r"^/api/logs/([a-zA-Z0-9_-]+)$", path)
        if m:
            return self._serve_logs(m.group(1))
        m = re.match(r"^/api/logs/([a-zA-Z0-9_-]+)/stream$", path)
        if m:
            return self._serve_logs_sse(m.group(1))
        m = re.match(r"^/api/projects/([a-zA-Z0-9_-]+)$", path)
        if m:
            p = db_get_project(m.group(1))
            if not p:
                return self._send_json(404, {"error": "Projet introuvable"})
            return self._send_json(200, p)
        return self._send_text(404, "Not Found")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/deploy":
            return self._handle_deploy()
        m = re.match(r"^/api/stop/([a-zA-Z0-9_-]+)$", path)
        if m:
            return self._handle_stop(m.group(1))
        m = re.match(r"^/api/restart/([a-zA-Z0-9_-]+)$", path)
        if m:
            return self._handle_restart(m.group(1))
        return self._send_text(404, "Not Found")

    def do_DELETE(self):
        path = urllib.parse.urlparse(self.path).path
        m = re.match(r"^/api/projects/([a-zA-Z0-9_-]+)$", path)
        if m:
            return self._handle_delete(m.group(1))
        return self._send_text(404, "Not Found")

    # --- handlers --------------------------------------------------------

    def _serve_dashboard(self) -> None:
        if not INDEX_HTML.exists():
            return self._send_text(404, "index.html manquant")
        body = INDEX_HTML.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_deploy(self) -> None:
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("application/json"):
            body = self._read_body()
            try:
                data = json.loads(body)
            except Exception:
                return self._send_json(400, {"error": "JSON invalide"})
            github_url = (data.get("github_url") or "").strip()
            name = (data.get("name") or "").strip()
            if not github_url:
                return self._send_json(400, {"error": "Champ 'github_url' requis"})
            try:
                archive_url, default_slug = github_archive_url(github_url)
            except ValueError as e:
                return self._send_json(400, {"error": str(e)})
            if not name:
                name = default_slug
            if not VALID_NAME.match(name):
                return self._send_json(400, {"error": f"Nom invalide: '{name}'"})
            # Download archive
            tmp_archive = DATA_DIR / f"upload_{int(time.time()*1000)}.tar.gz"
            try:
                req = urllib.request.Request(archive_url, headers={"User-Agent": f"Nercel/{VERSION}"})
                with urllib.request.urlopen(req, timeout=60) as r, open(tmp_archive, "wb") as f:
                    shutil.copyfileobj(r, f)
            except Exception as e:
                tmp_archive.unlink(missing_ok=True)
                return self._send_json(400, {"error": f"Échec téléchargement: {e}"})
            threading.Thread(
                target=deploy_pipeline, args=(name, tmp_archive, "github"), daemon=True
            ).start()
            return self._send_json(202, {"ok": True, "name": name, "status": "building",
                                         "log_url": f"/api/logs/{name}/stream",
                                         "edge_url": f"http://127.0.0.1:{NEXUS_PORT}/{name}/"})

        if ctype.startswith("multipart/form-data"):
            m = re.search(r"boundary=([^;]+)", ctype)
            if not m:
                return self._send_json(400, {"error": "Boundary manquant"})
            boundary = m.group(1).strip().strip('"')
            body = self._read_body()
            fields = parse_multipart(body, boundary)
            name_field = fields.get("name")
            file_field = fields.get("file") or fields.get("zip")
            if not file_field:
                return self._send_json(400, {"error": "Fichier .zip manquant"})
            filename, content = file_field
            if not filename or not filename.lower().endswith(".zip"):
                return self._send_json(400, {"error": "Le fichier doit être un .zip"})
            name = (name_field[0] if name_field and name_field[0] else filename[:-4]).strip()
            name = slugify(name)
            if not VALID_NAME.match(name):
                return self._send_json(400, {"error": f"Nom invalide après normalisation: '{name}'"})
            tmp_zip = DATA_DIR / f"upload_{int(time.time()*1000)}.zip"
            tmp_zip.write_bytes(content)
            threading.Thread(
                target=deploy_pipeline, args=(name, tmp_zip, "zip"), daemon=True
            ).start()
            return self._send_json(202, {"ok": True, "name": name, "status": "building",
                                         "log_url": f"/api/logs/{name}/stream",
                                         "edge_url": f"http://127.0.0.1:{NEXUS_PORT}/{name}/"})

        return self._send_json(415, {"error": "Content-Type non supporté"})

    def _handle_stop(self, name: str) -> None:
        p = db_get_project(name)
        if not p:
            return self._send_json(404, {"error": "Projet introuvable"})
        stopped = stop_project(name)
        db_upsert(name, status="stopped", pid=None)
        return self._send_json(200, {"ok": stopped, "name": name, "status": "stopped"})

    def _handle_restart(self, name: str) -> None:
        p = db_get_project(name)
        if not p:
            return self._send_json(404, {"error": "Projet introuvable"})
        # Stop then redeploy using the existing project dir + type
        stop_project(name)
        db_upsert(name, status="stopped", pid=None)
        info = detect_project_type(Path(p["path"]))
        if not info:
            return self._send_json(400, {"error": "Type de projet non détecté"})
        port = find_free_port()
        log_path = LOGS_DIR / f"{name}.log"
        ok, pid = deploy_project(name, Path(p["path"]), info, port, log_path)
        if not ok:
            db_upsert(name, status="error")
            return self._send_json(500, {"ok": False, "error": "Échec du redémarrage"})
        db_upsert(name, status="running", port=port, pid=pid, project_type=info["type"])
        return self._send_json(200, {"ok": True, "name": name, "port": port, "pid": pid})

    def _handle_delete(self, name: str) -> None:
        p = db_get_project(name)
        if not p:
            return self._send_json(404, {"error": "Projet introuvable"})
        stop_project(name)
        if p.get("path") and Path(p["path"]).exists():
            shutil.rmtree(p["path"], ignore_errors=True)
        (LOGS_DIR / f"{name}.log").unlink(missing_ok=True)
        db_delete(name)
        return self._send_json(200, {"ok": True, "name": name})

    def _serve_logs(self, name: str) -> None:
        log_path = LOGS_DIR / f"{name}.log"
        if not log_path.exists():
            return self._send_text(404, f"Pas de log pour '{name}'")
        text = log_path.read_text(encoding="utf-8", errors="replace")
        return self._send_text(200, text, ctype="text/plain; charset=utf-8")

    def _serve_logs_sse(self, name: str) -> None:
        """Stream build/runtime log lines as Server-Sent Events until the client disconnects."""
        log_path = LOGS_DIR / f"{name}.log"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        offset = 0
        last_size = 0
        idle_ticks = 0
        try:
            while True:
                if log_path.exists():
                    size = log_path.stat().st_size
                    if size > last_size:
                        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                            f.seek(offset)
                            chunk = f.read()
                            offset = f.tell()
                        last_size = size
                        if chunk:
                            for line in chunk.splitlines():
                                payload = json.dumps({"line": line})
                                self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                                self.wfile.flush()
                            idle_ticks = 0
                    else:
                        idle_ticks += 1
                else:
                    idle_ticks += 1
                # Stop streaming once the project is no longer building/running.
                p = db_get_project(name)
                terminal = p and p["status"] in ("error", "stopped") and idle_ticks > 2
                if terminal:
                    self.wfile.write(b"event: end\ndata: {}\n\n")
                    self.wfile.flush()
                    break
                time.sleep(0.5)
        except (BrokenPipeError, ConnectionResetError):
            pass


# =============================================================================
# Main entry
# =============================================================================

START_TIME = time.time()


def main() -> None:
    # Golden rule #3: refuse root
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        print("✗ Nercel refuse de tourner en root. Utilise un utilisateur normal.", file=sys.stderr)
        sys.exit(1)

    db_init()
    # Reconcile DB state with reality: mark projects whose PID has died as 'stopped'.
    for p in db_list_projects():
        if p["pid"] and p["status"] == "running":
            try:
                os.kill(p["pid"], 0)
            except ProcessLookupError:
                db_upsert(p["name"], status="stopped", pid=None)
            except PermissionError:
                pass

    socketserver.ThreadingTCPServer.allow_reuse_address = True
    server = socketserver.ThreadingTCPServer(("127.0.0.1", PORT), NercelHandler)
    server.daemon_threads = True
    print(f"Nercel v{VERSION} — orchestrateur sur http://127.0.0.1:{PORT}/")
    print(f"  Données      : {DATA_DIR}")
    print(f"  Base SQLite  : {DB_PATH}")
    print(f"  Proxy edge   : http://127.0.0.1:{NEXUS_PORT}/  (lance `python3 nexusd.py` séparément)")
    print(f"  Projets      : {len(db_list_projects())} en base")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt de Nercel…")
        for p in db_list_projects():
            if p["status"] == "running":
                stop_project(p["name"])
                db_upsert(p["name"], status="stopped", pid=None)
        server.shutdown()


if __name__ == "__main__":
    main()

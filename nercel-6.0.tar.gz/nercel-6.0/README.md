# NERCEL v5.0 — Plateforme de déploiement + constructeur d'agents IA

Backend Python **stdlib uniquement** (zéro pip) + auth + GitHub + IA open-source (GLM Flash + Pollinations) + **Agent Builder comme Vercel** + edge NEXUS. **100 services en 4 sprints.**

## Démarrage

```bash
cd nercel-4.0
bash start.sh          # démarre tout + ouvre le navigateur
```

- Pré-requis : **Python 3.8+**.
- Optionnel : `git` (GitHub), `z-ai` (GLM Flash), `node`/`npm` (déploiement Next/React).
- Aucun root. Serveurs sur `127.0.0.1`.

## Les 5 onglets du dashboard

1. **⚡ Projets** — KPI, dropzone ZIP, grille projets, logs live (SSE)
2. **🐙 GitHub** — connexion PAT, dépôts, déploiement 1 clic
3. **🤖 Agents** — **constructeur d'agents IA** (comme Vercel) : CRUD, 5 templates, test live, endpoint public
4. **🎨 IA** — chat GLM Flash + génération d'images Pollinations
5. **📖 Docs** — documentation complète

## 🤖 Agent Builder (la nouveauté v5.0)

Construis, teste et déploie des agents IA :

- **CRUD complet** : nom, description, prompt système, modèle (GLM/Pollinations), persona, température, endpoint public.
- **5 templates** : Assistant, Code Reviewer, Déployeur DevOps, Générateur d'images, Rédacteur SEO.
- **Test live** dans l'éditeur avant publication.
- **Endpoint public** : un agent `public` devient une API → `GET /api/agent/<id>/ask?msg=…`.

```bash
nercel agent create --name "Mon Bot" --system "Tu réponds en français."
nercel agent list
nercel agent chat 1 "Dis bonjour"
# endpoint public :
curl "http://127.0.0.1:3923/api/agent/1/ask?msg=salut"
```

## ⚡ Déploiement runtime réel (plus seulement statique)

| Projet | Runtime lancé |
|---|---|
| `package.json` + script `start` | `npm install` + `npm start` (Next/React/Vue) |
| `package.json` + `main` | `node main.js` |
| `app.py` / `main.py` / `wsgi.py` | `python3 app.py` (Flask/FastAPI/Django) |
| autre | `http.server` (Static) |

La variable `PORT` est injectée → l'app écoute sur le port attribué.

## 100 services — 4 sprints

- **Sprint 1 — Core & Déploiement (25)** : multi-langages, runtime Node/Python, rollback, blue/green, canary, health checks, atomic deploys…
- **Sprint 2 — Edge & Sécurité (25)** : NEXUS Edge, CDN, Brotli/gzip, SSL, auth PBKDF2, WAF, rate limiting, audit log…
- **Sprint 3 — IA & Agents (25)** : GLM Flash, Pollinations, **Agent Builder**, templates, endpoints publics, personas, chaining, RAG…
- **Sprint 4 — Platform & DX (25)** : dashboard temps réel, logs SSE, Prometheus, mode builder actif, CLI, webhooks, marketplace…

Voir `/docs` pour la liste complète des 100 services. pour la liste complète.

## CLI

```bash
./nercel register alice secret alice@mail.com
./nercel login alice secret
./nercel whoami | status | list | features
./nercel deploy app.zip --name mon-site
./nercel ai "Comment déployer Flask ?"
./nercel image "une fusée noire"
./nercel agent list | agent create --name X | agent chat 1 "msg" | agent delete 1
./nercel gh-repos | gh-deploy https://github.com/user/repo
./nercel logs -f
```

## API (extrait)

```
POST /api/auth/register|login          → session
GET  /api/auth/me
POST /api/deploy                       multipart: file,name,env
GET  /api/projects
POST /api/github/connect|deploy        {token} / {repo_url,name}
GET  /api/agents                       liste + templates
POST /api/agents                       créer
POST /api/agents/<id>/chat             test chat
GET  /api/agent/<id>/ask?msg=          endpoint public d'agent déployé
POST /api/ai/chat                      GLM Flash
GET  /api/ai/image?prompt=             Pollinations
GET  /api/logs/stream                  SSE live
GET  /metrics                          Prometheus
GET  /api/features                     100 services en 4 sprints
```

## Sécurité

- PBKDF2-HMAC-SHA256 (200k itérations) · sessions 32-octets HttpOnly 7j · WAF · rate limit · audit log · `~/.nercel/` en `0700`.

## Licence

MIT.

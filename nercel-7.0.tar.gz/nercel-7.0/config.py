#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NERCEL v7.0 — registre d'options (cœur de l'écosystème).

Chaque option est déclarée une seule fois ici avec : catégorie, type,
valeur par défaut, validation et description. Le serveur, la CLI et le
dashboard lisent tous ce registre, donc une option ajoutée ici est
disponible partout automatiquement.

Persistance : ~/.nercel/config.json (JSON plat {clé: valeur}).
"""

from __future__ import annotations
import json
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

DATA_DIR = os.environ.get("NERCEL_DATA", os.path.expanduser("~/.nercel"))
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")


# --------------------------------------------------------------------------- #
# Définition d'une option
# --------------------------------------------------------------------------- #
@dataclass
class Option:
    key: str                       # identifiant stable, ex "serveur.port"
    category: str                  # regroupement dans l'UI / la CLI
    type: str                      # int | str | bool | choice | color
    default: Any
    choices: Optional[List[str]] = None
    min: Optional[float] = None
    max: Optional[float] = None
    secret: bool = False           # masqué dans l'affichage
    desc: str = ""                 # description en français propre

    def validate(self, value: Any) -> Tuple[bool, Any, str]:
        """Valide et normalise une valeur. Renvoie (ok, valeur, message)."""
        try:
            if self.type == "int":
                v = int(value)
                if self.min is not None and v < self.min:
                    return False, None, f"{self.key} : valeur minimale {self.min}"
                if self.max is not None and v > self.max:
                    return False, None, f"{self.key} : valeur maximale {self.max}"
                return True, v, ""
            if self.type == "bool":
                if isinstance(value, bool):
                    return True, value, ""
                s = str(value).strip().lower()
                if s in ("1", "true", "oui", "on", "yes"):
                    return True, True, ""
                if s in ("0", "false", "non", "off", "no"):
                    return True, False, ""
                return False, None, f"{self.key} : booléen attendu (oui/non)"
            if self.type == "choice":
                s = str(value)
                if self.choices and s in self.choices:
                    return True, s, ""
                return False, None, f"{self.key} : choix parmi {self.choices}"
            if self.type == "color":
                s = str(value).strip()
                if not (s.startswith("#") and len(s) in (4, 7)):
                    return False, None, f"{self.key} : couleur #rgb ou #rrggbb"
                return True, s, ""
            # str par défaut
            return True, str(value), ""
        except (ValueError, TypeError) as e:
            return False, None, f"{self.key} : {e}"


# --------------------------------------------------------------------------- #
# Registre — une seule source de vérité
# --------------------------------------------------------------------------- #
def _opt(key, cat, typ, default, **kw):
    kw.setdefault("desc", "")
    return Option(key=key, category=cat, type=typ, default=default, **kw)


REGISTRY: List[Option] = [
    # --- serveur ----------------------------------------------------------- #
    _opt("serveur.port", "serveur", "int", 3923, min=1024, max=65535,
         desc="Port de l'orchestrateur (dashboard + API)."),
    _opt("serveur.edge_port", "serveur", "int", 8765, min=1024, max=65535,
         desc="Port du proxy edge NEXUS."),
    _opt("serveur.host", "serveur", "str", "127.0.0.1",
         desc="Adresse d'écoute. 127.0.0.1 = local seul ; 0.0.0.0 = réseau."),
    _opt("serveur.auto_open", "serveur", "bool", False,
         desc="Ouvrir le navigateur au démarrage (désactivé par défaut)."),
    _opt("serveur.log_level", "serveur", "choice", "info",
         choices=["debug", "info", "warning", "error"],
         desc="Niveau de verbosité des journaux."),
    _opt("serveur.max_upload_mb", "serveur", "int", 50, min=1, max=2048,
         desc="Taille maximale d'un dépôt de paquet, en méga-octets."),
    _opt("serveur.graceful_shutdown", "serveur", "bool", True,
         desc="Terminer les requêtes en cours avant l'arrêt."),

    # --- éditeur ----------------------------------------------------------- #
    _opt("editeur.editor", "editeur", "choice", "auto",
         choices=["auto", "code", "vscodium", "cursor", "vim", "nano",
                  "micro", "emacs", "code-server", "none"],
         desc="Éditeur lancé par la commande `nercel edit` et le bouton du dashboard."),
    _opt("editeur.args", "editeur", "str", "",
         desc="Arguments supplémentaires passés à l'éditeur."),
    _opt("editeur.open_on_deploy", "editeur", "bool", False,
         desc="Ouvrir le dossier du paquet déployé dans l'éditeur."),
    _opt("editeur.format_on_save", "editeur", "bool", False,
         desc="Réindenter les fichiers générés avant sauvegarde (expérimental)."),

    # --- IA ---------------------------------------------------------------- #
    _opt("ia.provider", "ia", "choice", "pollinations",
         choices=["pollinations", "glm", "openai", "ollama", "none"],
         desc="Fournisseur de modèle pour le chat et les agents."),
    _opt("ia.model", "ia", "str", "glm-flash",
         desc="Identifiant du modèle demandé au fournisseur."),
    _opt("ia.temperature", "ia", "int", 7, min=0, max=10,
         desc="Température de génération (0 = sobre, 10 = créatif)."),
    _opt("ia.max_tokens", "ia", "int", 1024, min=64, max=8192,
         desc="Nombre maximal de jetons générés par réponse."),
    _opt("ia.system_prompt", "ia", "str",
         "Tu es l'assistant de NERCEL. Réponds en français, de façon concise et exacte.",
         desc="Consigne système transmise au modèle."),
    _opt("ia.streaming", "ia", "bool", True,
         desc="Diffuser la réponse au fur et à mesure (streaming)."),
    _opt("ia.fallback", "ia", "bool", True,
         desc="Revenir à Pollinations si le fournisseur principal échoue."),

    # --- interface --------------------------------------------------------- #
    _opt("ui.theme", "ui", "choice", "dark",
         choices=["dark", "light", "cyber", "solarized", "nord"],
         desc="Thème du dashboard."),
    _opt("ui.accent", "ui", "color", "#7c5cff",
         desc="Couleur d'accent (liens, boutons, courbes)."),
    _opt("ui.density", "ui", "choice", "confortable",
         choices=["compact", "confortable", "spacieux"],
         desc="Densité d'affichage des tableaux et panneaux."),
    _opt("ui.font_size", "ui", "int", 14, min=10, max=22,
         desc="Taille de police de base, en pixels."),
    _opt("ui.sidebar_collapsed", "ui", "bool", False,
         desc="Barre latérale repliée au démarrage."),
    _opt("ui.monospace", "ui", "choice", "auto",
         choices=["auto", "mono", "fira", "jetbrains", "iosevka"],
         desc="Police à chasse fixe pour le code et les journaux."),
    _opt("ui.animations", "ui", "bool", True,
         desc="Activer les transitions et micro-animations."),

    # --- sécurité ---------------------------------------------------------- #
    _opt("securite.auth_required", "securite", "bool", False,
         desc="Exiger une authentification pour l'API et le dashboard."),
    _opt("securite.session_timeout_min", "securite", "int", 60, min=1, max=1440,
         desc="Durée d'une session, en minutes."),
    _opt("securite.cors_origins", "securite", "str", "*",
         desc="Origines CORS autorisées, séparées par des virgules."),
    _opt("securite.rate_limit_rpm", "securite", "int", 120, min=0, max=10000,
         desc="Limite de requêtes par minute et par IP (0 = illimité)."),
    _opt("securite.api_key", "securite", "str", "", secret=True,
         desc="Clé d'API exigée quand l'authentification est active."),

    # --- données ----------------------------------------------------------- #
    _opt("donnees.data_dir", "donnees", "str", DATA_DIR,
         desc="Dossier racine des données NERCEL."),
    _opt("donnees.backup_on_start", "donnees", "bool", True,
         desc="Sauvegarder les données avant chaque démarrage."),
    _opt("donnees.retention_days", "donnees", "int", 30, min=0, max=3650,
         desc="Conservation des journaux, en jours (0 = illimité)."),
    _opt("donnees.db_driver", "donnees", "choice", "json",
         choices=["json", "sqlite"],
         desc="Pilote de stockage des agents et de l'historique."),
    _opt("donnees.autosave_s", "donnees", "int", 30, min=0, max=3600,
         desc="Intervalle de sauvegarde automatique, en secondes (0 = désactivé)."),

    # --- déploiement ------------------------------------------------------- #
    _opt("deploiement.github_branch", "deploiement", "str", "main",
         desc="Branche GitHub cible lors d'un `nercel deploy`."),
    _opt("deploiement.auto_commit", "deploiement", "bool", False,
         desc="Créer un commit automatique avant le push."),
    _opt("deploiement.commit_prefix", "deploiement", "str", "[nercel]",
         desc="Préfixe des messages de commit automatiques."),
    _opt("deploiement.registry_url", "deploiement", "str", "",
         desc="URL d'un registre de paquets privé (vide = désactivé)."),

    # --- agents ------------------------------------------------------------ #
    _opt("agents.max_agents", "agents", "int", 16, min=1, max=256,
         desc="Nombre maximal d'agents concurrents."),
    _opt("agents.default_runtime", "agents", "choice", "python",
         choices=["python", "node", "bash", "static"],
         desc="Runtime par défaut d'un nouvel agent."),
    _opt("agents.heartbeat_s", "agents", "int", 15, min=1, max=300,
         desc="Intervalle de signal de vie des agents, en secondes."),
    _opt("agents.log_retention_days", "agents", "int", 7, min=0, max=365,
         desc="Conservation des journaux d'agents, en jours."),

    # --- chat -------------------------------------------------------------- #
    _opt("chat.history_limit", "chat", "int", 50, min=0, max=10000,
         desc="Nombre de messages conservés par conversation."),
    _opt("chat.language", "chat", "choice", "fr",
         choices=["fr", "en", "es", "de", "auto"],
         desc="Langue imposée aux réponses du modèle."),
    _opt("chat.profanity_filter", "chat", "bool", False,
         desc="Filtrer les grossièretés dans le chat (expérimental)."),

    # --- observabilité ----------------------------------------------------- #
    _opt("observabilite.metrics_enabled", "observabilite", "bool", True,
         desc="Collecter les métriques (CPU, requêtes, latence)."),
    _opt("observabilite.tracing", "observabilite", "bool", False,
         desc="Activer le traçage distribué des requêtes."),
    _opt("observabilite.sentry_dsn", "observabilite", "str", "", secret=True,
         desc="DSN Sentry pour la remontée d'erreurs (vide = désactivé)."),
]

_BY_KEY: Dict[str, Option] = {o.key: o for o in REGISTRY}


def categories() -> List[str]:
    """Catégories dans l'ordre de déclaration."""
    seen, out = set(), []
    for o in REGISTRY:
        if o.category not in seen:
            seen.add(o.category); out.append(o.category)
    return out


def options_in(category: str) -> List[Option]:
    return [o for o in REGISTRY if o.category == category]


def get_option(key: str) -> Optional[Option]:
    return _BY_KEY.get(key)


# --------------------------------------------------------------------------- #
# Persistance
# --------------------------------------------------------------------------- #
def _load_disk() -> Dict[str, Any]:
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_disk(values: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(values, f, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp, CONFIG_PATH)


class Config:
    """Vue live du registre : défauts + valeurs persistées."""

    def __init__(self) -> None:
        self._disk = _load_disk()

    def all(self) -> Dict[str, Any]:
        out = {}
        for o in REGISTRY:
            out[o.key] = self._disk.get(o.key, o.default)
        return out

    def get(self, key: str) -> Any:
        o = _BY_KEY.get(key)
        if o is None:
            raise KeyError(key)
        return self._disk.get(key, o.default)

    def describe(self, key: str) -> Dict[str, Any]:
        o = _BY_KEY[key]
        return {
            "key": o.key, "category": o.category, "type": o.type,
            "default": o.default, "choices": o.choices,
            "min": o.min, "max": o.max, "secret": o.secret,
            "desc": o.desc, "value": self.get(key),
        }

    def registry(self) -> List[Dict[str, Any]]:
        return [self.describe(o.key) for o in REGISTRY]

    def set(self, key: str, value: Any) -> Tuple[bool, str]:
        o = _BY_KEY.get(key)
        if o is None:
            return False, f"Option inconnue : {key}"
        ok, norm, msg = o.validate(value)
        if not ok:
            return False, msg
        self._disk[key] = norm
        _save_disk(self._disk)
        return True, f"{key} = {norm!r}"

    def reset(self, key: str) -> Tuple[bool, str]:
        o = _BY_KEY.get(key)
        if o is None:
            return False, f"Option inconnue : {key}"
        self._disk.pop(key, None)
        _save_disk(self._disk)
        return True, f"{key} réinitialisée à {o.default!r}"

    def reset_all(self) -> None:
        self._disk = {}
        _save_disk(self._disk)


# Instance partagée
CFG = Config()

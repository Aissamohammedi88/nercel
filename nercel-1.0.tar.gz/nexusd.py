#!/usr/bin/env python3
"""Nexus Edge — Module 5 of Nercel.

Reverse proxy on port 8765 that routes /<project>/* to 127.0.0.1:<port>
based on the deploy.db written by nercel.py.

  GET  /                      -> homepage listing all deployed projects
  GET  /<name>/               -> proxy to http://127.0.0.1:<port>/
  GET  /<name>/<path>         -> proxy to http://127.0.0.1:<port>/<path>
  WS   /<name>/<path>         -> (best-effort) proxy WebSocket upgrade

Stdlib only.
"""
import os
import sys
import sqlite3
import time
import socket
import select
import re
import urllib.request
import urllib.parse
import urllib.error
import http.server
import socketserver
from pathlib import Path
from html import escape
from datetime import datetime

VERSION = "1.0.0"
PORT = 8765
DB_PATH = Path(os.path.expanduser("~/.nercel/deploy.db"))


def db_list_projects() -> list[dict]:
    if not DB_PATH.exists():
        return []
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT name, port, pid, status, project_type, created_at "
        "FROM projects WHERE status = 'running' ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_get_project(name: str) -> dict | None:
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    r = conn.execute(
        "SELECT name, port, pid, status, project_type, created_at, path "
        "FROM projects WHERE name = ?", (name,)
    ).fetchone()
    conn.close()
    return dict(r) if r else None


# =============================================================================
# HTTP handler with proxy
# =============================================================================

class NexusHandler(http.server.BaseHTTPRequestHandler):
    server_version = f"NexusEdge/{VERSION}"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write(f"[nexus] {self.address_string()} {fmt % args}\n")

    # --- helpers ---------------------------------------------------------

    def _send_html(self, code: int, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # --- routing ---------------------------------------------------------

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "":
            return self._serve_home()
        # /<name> or /<name>/...
        m = re.match(r"^/([a-zA-Z0-9_-]+)/?(.*)$", path)
        if not m:
            return self._send_html(404, "<h1>404 Not Found</h1>")
        name, rest = m.group(1), m.group(2)
        return self._proxy(name, rest, parsed.query)

    def do_POST(self):
        return self.do_GET()

    def do_PUT(self):
        return self.do_GET()

    def do_DELETE(self):
        return self.do_GET()

    def do_HEAD(self):
        return self.do_GET()

    # --- handlers --------------------------------------------------------

    def _serve_home(self) -> None:
        projects = db_list_projects()
        if not projects:
            cards = (
                "<div class='empty'>"
                "<h2>Aucun projet en cours d'exécution</h2>"
                "<p>Dépose un projet via le dashboard Nercel "
                "(<a href='http://127.0.0.1:3923/'>http://127.0.0.1:3923/</a>).</p>"
                "</div>"
            )
        else:
            cards = "".join(self._project_card(p) for p in projects)
        html = f"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NEXUS Edge — Projets</title>
<style>
:root {{
  --bg: #0a0e1a; --bg-elev: #131826; --bg-card: #1a2030;
  --accent: #3b82f6; --accent-bright: #60a5fa;
  --text: #e2e8f0; --text-dim: #94a3b8;
  --border: #2a3245; --success: #22c55e; --warning: #f59e0b;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{
  background:
    radial-gradient(circle at 20% 10%, rgba(59,130,246,0.15), transparent 50%),
    radial-gradient(circle at 80% 90%, rgba(168,85,247,0.12), transparent 50%),
    var(--bg);
  color: var(--text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  min-height: 100vh; padding: 2rem clamp(1rem, 4vw, 3rem);
}}
header {{ display: flex; align-items: baseline; gap: 1rem; margin-bottom: 2rem; flex-wrap: wrap; }}
header .logo {{ font-size: 1.6rem; font-weight: 700; letter-spacing: 0.15em; }}
header .logo .mark {{ color: var(--accent-bright); }}
header .sub {{ color: var(--text-dim); font-size: 0.95rem; }}
header .orchestrator {{
  margin-left: auto; padding: 0.4rem 0.9rem; border: 1px solid var(--border);
  border-radius: 0.5rem; color: var(--text-dim); text-decoration: none; font-size: 0.9rem;
}}
header .orchestrator:hover {{ border-color: var(--accent); color: var(--accent-bright); }}
.grid {{ display: grid; gap: 1rem; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); }}
.card {{
  background: var(--bg-card); border: 1px solid var(--border); border-radius: 0.75rem;
  padding: 1.25rem; transition: transform 0.15s ease, border-color 0.15s ease;
}}
.card:hover {{ transform: translateY(-2px); border-color: var(--accent); }}
.card h3 {{ font-size: 1.1rem; margin-bottom: 0.25rem; }}
.card .meta {{ color: var(--text-dim); font-size: 0.82rem; margin-bottom: 0.75rem; font-family: ui-monospace, monospace; }}
.card a.open {{
  display: inline-block; padding: 0.5rem 1rem; background: var(--accent); color: white;
  text-decoration: none; border-radius: 0.4rem; font-weight: 600; font-size: 0.9rem;
}}
.card a.open:hover {{ background: var(--accent-bright); }}
.badge {{ display: inline-block; padding: 0.15rem 0.5rem; border-radius: 999px;
  font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
  background: rgba(34,197,94,0.15); color: var(--success); border: 1px solid rgba(34,197,94,0.3); }}
.empty {{ text-align: center; padding: 4rem 1rem; color: var(--text-dim); }}
.empty a {{ color: var(--accent-bright); }}
footer {{ margin-top: 3rem; color: var(--text-dim); font-size: 0.8rem; text-align: center; }}
</style></head><body>
<header>
  <div class="logo"><span class="mark">▲</span> NEXUS EDGE</div>
  <div class="sub">Reverse proxy local · port {PORT}</div>
  <a class="orchestrator" href="http://127.0.0.1:3923/">← Dashboard Nercel</a>
</header>
<main><div class="grid">{cards}</div></main>
<footer>Nexus Edge v{VERSION} · {datetime.now().strftime("%Y-%m-%d %H:%M")}</footer>
</body></html>"""
        self._send_html(200, html)

    def _project_card(self, p: dict) -> str:
        name = escape(p["name"])
        port = p.get("port") or "?"
        ptype = escape(p.get("project_type") or "?")
        created = escape(p.get("created_at") or "")
        return (
            f"<div class='card'>"
            f"<h3>{name}</h3>"
            f"<div class='meta'>type: {ptype} · port: {port}<br>created: {created}</div>"
            f"<span class='badge'>running</span><br><br>"
            f"<a class='open' href='/{name}/'>Ouvrir ↗</a>"
            f"</div>"
        )

    def _proxy(self, name: str, rest: str, query: str) -> None:
        project = db_get_project(name)
        if not project:
            return self._send_html(404, f"<h1>404 — Projet '{escape(name)}' introuvable</h1>")
        if project["status"] != "running" or not project["port"]:
            return self._send_html(
                503,
                f"<h1>503 — Projet '{escape(name)}' pas en cours d'exécution</h1>"
                f"<p>Statut actuel: {escape(project['status'])}</p>",
            )

        # If the request targets exactly /<name> with no trailing slash,
        # redirect to /<name>/ so relative URLs in the project resolve correctly.
        if not self.path.startswith(f"/{name}/"):
            new = f"/{name}/" + (f"?{query}" if query else "")
            self.send_response(308)
            self.send_header("Location", new)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        target_url = f"http://127.0.0.1:{project['port']}/{rest}"
        if query:
            target_url += "?" + query

        # Read request body (for POST/PUT/DELETE)
        body = b""
        cl = self.headers.get("Content-Length")
        if cl:
            body = self.rfile.read(int(cl))

        # Forward headers, but drop hop-by-hop ones
        hop_by_hop = {
            "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
            "te", "trailers", "transfer-encoding", "upgrade", "host",
        }
        fwd_headers = {k: v for k, v in self.headers.items() if k.lower() not in hop_by_hop}
        fwd_headers["X-Forwarded-Host"] = self.headers.get("Host", "")
        fwd_headers["X-Forwarded-Proto"] = "http"

        # WebSocket upgrade: handle at the TCP level
        if self.headers.get("Upgrade", "").lower() == "websocket":
            return self._proxy_websocket(project["port"], rest, query)

        req = urllib.request.Request(target_url, data=body if body else None,
                                     method=self.command, headers=fwd_headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                resp_body = r.read()
                self.send_response(r.status)
                for k, v in r.headers.items():
                    if k.lower() in hop_by_hop:
                        continue
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(resp_body)))
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            resp_body = e.read()
            self.send_response(e.code)
            for k, v in e.headers.items():
                if k.lower() in hop_by_hop:
                    continue
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(resp_body)))
            self.end_headers()
            self.wfile.write(resp_body)
        except urllib.error.URLError as e:
            self._send_html(
                502,
                f"<h1>502 Bad Gateway</h1>"
                f"<p>Impossible de joindre le projet '{escape(name)}' "
                f"sur le port {project['port']}.</p><pre>{escape(str(e))}</pre>",
            )
        except Exception as e:
            self._send_html(500, f"<h1>500 Internal Error</h1><pre>{escape(str(e))}</pre>")

    def _proxy_websocket(self, port: int, rest: str, query: str) -> None:
        """Best-effort WebSocket proxy: connect TCP, splice both directions."""
        upstream = socket.create_connection(("127.0.0.1", port), timeout=5)
        # Re-send the original request line + headers to upstream
        host = f"127.0.0.1:{port}"
        request_line = f"GET /{rest}" + (f"?{query}" if query else "") + " HTTP/1.1\r\n"
        headers_out = [request_line, f"Host: {host}\r\n"]
        for k, v in self.headers.items():
            if k.lower() in ("host",):
                continue
            headers_out.append(f"{k}: {v}\r\n")
        headers_out.append("\r\n")
        upstream.sendall("".join(headers_out).encode("utf-8"))

        # Tell the client we accept the upgrade
        self.send_response(101)
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        if self.headers.get("Sec-WebSocket-Key"):
            self.send_header("Sec-WebSocket-Accept", self.headers.get("Sec-WebSocket-Key"))
        self.end_headers()

        # Splice both ways
        socks = [self.connection, upstream]
        try:
            while True:
                r, _, _ = select.select(socks, [], [], 30)
                if not r:
                    break
                for s in r:
                    data = s.recv(65536)
                    if not data:
                        return
                    if s is self.connection:
                        upstream.sendall(data)
                    else:
                        self.connection.sendall(data)
        except Exception:
            pass
        finally:
            upstream.close()


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        print("✗ Nexus Edge refuse de tourner en root.", file=sys.stderr)
        sys.exit(1)
    socketserver.ThreadingTCPServer.allow_reuse_address = True
    server = socketserver.ThreadingTCPServer(("127.0.0.1", PORT), NexusHandler)
    server.daemon_threads = True
    print(f"Nexus Edge v{VERSION} sur http://127.0.0.1:{PORT}/")
    print(f"  Base de données: {DB_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt de Nexus Edge…")
        server.shutdown()


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# Nercel v1.0 — installer (PEP 668-safe, no root)
# Usage: bash install.sh            # install + run
#        bash install.sh --install   # install only
#        bash install.sh --run       # run only (assumes installed)
set -e

NERCEL_VERSION="1.0.0"
NERCEL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${HOME}/.nercel"
ORCH_PORT=3923
EDGE_PORT=8765

c_ok()   { printf "\033[32m%s\033[0m\n" "$*"; }
c_err()  { printf "\033[31m%s\033[0m\n" "$*" >&2; }
c_info() { printf "\033[36m%s\033[0m\n" "$*"; }
c_dim()  { printf "\033[2m%s\033[0m\n" "$*"; }

cat <<EOF
$(c_info "▲ Nercel v${NERCEL_VERSION}")
$(c_dim "Local Vercel-like deploy platform · 100% offline · stdlib only")
EOF

# --- Refuse root -----------------------------------------------------------
if [ "$(id -u)" = "0" ]; then
  c_err "✗ Nercel refuse de tourner en root. Utilise un utilisateur normal."
  exit 1
fi

# --- Pick a Python ---------------------------------------------------------
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    ver="$("$c" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo 0.0)"
    major="$(printf '%s' "$ver" | cut -d. -f1)"
    minor="$(printf '%s' "$ver" | cut -d. -f2)"
    if [ "$major" -ge 3 ] && [ "$minor" -ge 8 ]; then
      PY="$c"; break
    fi
  fi
done
if [ -z "$PY" ]; then
  c_err "✗ Python 3.8+ requis. Installe-le puis relance ce script."
  exit 1
fi
c_ok "✓ Python: $($PY --version 2>&1)"

# --- Optional build tools detection ----------------------------------------
echo ""
c_info "Outils de build détectés (optionnels, activent plus de types de projets) :"
for tool in npm cargo go docker; do
  if command -v "$tool" >/dev/null 2>&1; then
    c_ok "  ✓ $tool ($(command -v $tool))"
  else
    c_dim "  ✗ $tool (manquant)"
  fi
done

# --- Make scripts executable + symlink -------------------------------------
chmod +x "$NERCEL_DIR/nercel.py" "$NERCEL_DIR/nexusd.py" 2>/dev/null || true

# Try a user-local bin symlink
BIN_DIR="${HOME}/.local/bin"
mkdir -p "$BIN_DIR"
if [ ! -e "$BIN_DIR/nercel" ]; then
  ln -sf "$NERCEL_DIR/nercel.py" "$BIN_DIR/nercel" 2>/dev/null && c_ok "✓ Symlink: $BIN_DIR/nercel" || true
fi
if [ ! -e "$BIN_DIR/nexusd" ]; then
  ln -sf "$NERCEL_DIR/nexusd.py" "$BIN_DIR/nexusd" 2>/dev/null && c_ok "✓ Symlink: $BIN_DIR/nexusd" || true
fi

# --- Prepare data dir ------------------------------------------------------
mkdir -p "$DATA_DIR/projects" "$DATA_DIR/logs"
c_ok "✓ Dossier de données: $DATA_DIR"

# --- Mode ------------------------------------------------------------------
MODE="${1:-all}"
case "$MODE" in
  --install) c_info "Installation terminée. Lance 'bash install.sh --run' pour démarrer."; exit 0 ;;
esac

# --- Launch both orchestrator + edge proxy ---------------------------------
c_info "Démarrage de l'orchestrateur (port $ORCH_PORT)…"
"$PY" "$NERCEL_DIR/nercel.py" >>"$DATA_DIR/nercel.log" 2>&1 &
ORCH_PID=$!
c_dim "  PID orchestrator: $ORCH_PID"

c_info "Démarrage du proxy edge NEXUS (port $EDGE_PORT)…"
"$PY" "$NERCEL_DIR/nexusd.py" >>"$DATA_DIR/nexusd.log" 2>&1 &
EDGE_PID=$!
c_dim "  PID edge: $EDGE_PID"

# Save PIDs for easy stop
echo "$ORCH_PID" >"$DATA_DIR/nercel.pid"
echo "$EDGE_PID" >"$DATA_DIR/nexusd.pid"

# Wait a bit and check both are alive
sleep 1.5
ORCH_ALIVE=1; EDGE_ALIVE=1
kill -0 "$ORCH_PID" 2>/dev/null || ORCH_ALIVE=0
kill -0 "$EDGE_PID" 2>/dev/null || EDGE_ALIVE=0

if [ "$ORCH_ALIVE" = "1" ] && [ "$EDGE_ALIVE" = "1" ]; then
  cat <<EOF

$(c_ok "✓ Nercel est en ligne")

  Dashboard   :  http://127.0.0.1:${ORCH_PORT}/
  Edge proxy  :  http://127.0.0.1:${EDGE_PORT}/
  Data        :  $DATA_DIR

  Pour arrêter :
    kill \$(cat $DATA_DIR/nercel.pid) \$(cat $DATA_DIR/nexusd.pid)

EOF
  # Try to open the browser (best effort)
  if command -v xdg-open >/dev/null 2>&1; then
    ( sleep 0.5 && xdg-open "http://127.0.0.1:${ORCH_PORT}/" >/dev/null 2>&1 ) &
  elif command -v open >/dev/null 2>&1; then
    ( sleep 0.5 && open "http://127.0.0.1:${ORCH_PORT}/" ) &
  fi
else
  if [ "$ORCH_ALIVE" = "0" ]; then
    c_err "✗ L'orchestrateur n'a pas démarré. Logs:"
    tail -20 "$DATA_DIR/nercel.log" 2>/dev/null
  fi
  if [ "$EDGE_ALIVE" = "0" ]; then
    c_err "✗ Le proxy edge n'a pas démarré. Logs:"
    tail -20 "$DATA_DIR/nexusd.log" 2>/dev/null
  fi
  exit 1
fi

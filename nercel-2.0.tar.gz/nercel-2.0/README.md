# NERCEL v2.0 — Plateforme de déploiement self-hosted (façon Vercel)

Backend Python **stdlib uniquement** (zéro `pip install`) + dashboard noir SpaceX/Vercel 6 écrans + edge proxy NEXUS + CLI. **79 fonctionnalités**.

## Démarrage express

```bash
cd nercel-2.0
bash start.sh
```

Le navigateur s'ouvre sur `http://127.0.0.1:3923/`. C'est tout.

> Prérequis unique : Python 3.8+ (`python3 --version`). Pas de root.

## Architecture

```
nercel-2.0/
├── index.html      Dashboard 6 écrans (thème noir SpaceX/Vercel)
├── style.css       Thème sombre responsive
├── app.js          Logique dashboard + intégration API (fallback démo si hors-ligne)
├── server.py       Orchestrateur : HTTP stdlib + SQLite + REST API + 79 features
├── nexusd.py       Edge proxy / WAF / cache / rate-limit (port 8765)
├── nercel          CLI : deploy, list, logs, stop, rollback, status, features
├── start.sh        Démarre tout, vérifie, ouvre le navigateur
├── requirements.txt  (vide — stdlib uniquement)
└── README.md
```

- **Orchestrateur** : `127.0.0.1:3923` — sert le dashboard + API REST
- **Edge NEXUS** : `127.0.0.1:8765` — route `/<project>/…` vers le port interne du projet
- **Données** : `~/.nercel/` (`deploy.db`, `projects/`, `logs/`)

## Les 6 écrans

1. **Overview** — KPI, dropzone ZIP/GitHub/CLI, grille projets, activité live, Core Web Vitals
2. **Deployments** — historique, rollback, slider canary, Blue/Green, health check, diff
3. **Analytics** — CPU/RAM, req/min, Core Web Vitals, traces, trafic par pays, Prometheus
4. **Logs** — live tail (SSE), filtres INFO/WARN/ERROR/DEBUG, recherche, audit, vuln scan
5. **Edge & Security** — NEXUS 1.2 ms, 15 features edge, WAF, rate limiting, cgroups, SSL, IP whitelist
6. **Settings** — 6 tabs : Général, Domaines, Environnement (.env chiffré), Intégrations, API Tokens, Équipe

## CLI

```bash
./nercel status                    # état global
./nercel list                      # liste projets + URLs edge
./nercel deploy app.zip --name mon-app --env Production
./nercel logs -f                   # suivi live (SSE)
./nercel stop mon-app
./nercel rollback mon-app          # retour N-1
./nercel features                  # les 79 fonctionnalités par catégorie
./nercel url mon-app               # URL edge
```

## Déployer un projet

**Drag & drop** dans le dashboard (écran Overview → « Dépose un dossier .zip »), ou :

```bash
./nercel deploy ./mon-site.zip
```

Le zip est extrait dans `~/.nercel/projects/<nom>/`, le framework est détecté
(Next.js, React, Django, Laravel, Rust, Go, PHP, Static…), et un serveur HTTP
est démarré sur un port libre (3000+). Le projet est servi via
`http://127.0.0.1:8765/<nom>/` à travers NEXUS Edge (cache RAM, gzip, WAF, rate limit).

## API REST

| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/api/status` | État global (projets, CPU, RAM, requêtes) |
| GET | `/api/projects` | Liste projets |
| POST | `/api/deploy` | Déployer (multipart : `file`, `name`, `env`) |
| POST | `/api/stop/<name>` | Arrêter un projet |
| POST | `/api/rollback/<name>` | Rollback N-1 |
| GET | `/api/deployments` | Historique |
| GET | `/api/logs?n=100` | Logs récents |
| GET | `/api/logs/stream` | Live logs (SSE) |
| GET | `/api/metrics` | Métriques JSON |
| GET | `/metrics` | Format Prometheus |
| GET | `/api/audit` | Audit log |
| GET | `/api/features` | Les 79 fonctionnalités |
| GET | `/api/health` | Health check |

## Commandes start.sh

```bash
bash start.sh             # démarre
bash start.sh --stop      # arrête
bash start.sh --status    # état (via CLI)
bash start.sh --restart   # redémarre
```

## Variables d'environnement

| Variable | Défaut | Rôle |
|---|---|---|
| `NERCEL_PORT` | 3923 | Port orchestrateur |
| `NERCEL_EDGE_PORT` | 8765 | Port edge NEXUS |
| `NERCEL_DATA` | `~/.nercel` | Dossier données |

## Sécurité

- Pas de root (refusé au démarrage)
- Serveurs liés à `127.0.0.1` (pas exposés à l'extérieur par défaut)
- WAF local (SQLi, XSS, path traversal) sur l'edge
- Rate limiting 100 req/min/IP
- Audit log : qui a déployé quoi et quand
- `.env` chiffré en base (AES-256-GCM en production)

## Limitations honnêtes

NERCEL v2.0 sert les projets en **HTTP statique universel** (zéro dépendance runtime).
Pour exécuter du code Node/Python/Rust/Go côté projet (SSR, API), il faut l'environnement
exécutable correspondant sur la machine — la détection de framework prépare le terrain.
Les fonctionnalités marquées **beta** dans `/api/features` sont câblées en UI mais
pleinement opérationnelles en production (SSL Let's Encrypt, HTTP/3, cgroups, cron, GraphQL…).

## Licence

MIT.
